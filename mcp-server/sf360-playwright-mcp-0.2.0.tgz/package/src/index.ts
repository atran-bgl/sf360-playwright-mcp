#!/usr/bin/env node

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

// ES module __dirname equivalent
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load prompt from markdown file in the consuming project
function loadPrompt(filename: string): string {
  // Prompts are in the consuming project at sf360-playwright/prompts/
  const promptPath = join(process.cwd(), 'sf360-playwright', 'prompts', filename);
  try {
    return readFileSync(promptPath, 'utf-8');
  } catch (error) {
    return `Error: Prompt file not found at ${promptPath}\n\nMake sure you ran 'npx sf360-mcp-init' to create the sf360-playwright/ folder structure.`;
  }
}

// Load prompt from package templates and inject variables
function loadPackagePrompt(promptName: string, variables: Record<string, string>): string {
  // Prompts are in package at templates/prompts/
  const promptsDir = join(__dirname, '../../templates/prompts');
  const promptPath = join(promptsDir, `${promptName}.md`);

  try {
    let prompt = readFileSync(promptPath, 'utf-8');

    // Inject variables
    for (const [key, value] of Object.entries(variables)) {
      const placeholder = `{{${key}}}`;
      prompt = prompt.replace(new RegExp(placeholder, 'g'), value);
    }

    return prompt;
  } catch (error) {
    return `Error: Prompt file not found at ${promptPath}\n\nThis is a package error - please report to maintainers.`;
  }
}

// Tool configuration interface
interface ToolConfig {
  name: string;
  description: string;
  inputSchema: any;  // JSON Schema - use any for flexibility
  promptFile: string;
  promptSource: 'project' | 'package';
  variableMapper?: (args: any) => Record<string, string>;
}

// Project tools (load from sf360-playwright/prompts/)
const projectTools: ToolConfig[] = [
  {
    name: 'init',
    description:
      'Initialize SF360 Playwright test infrastructure in this project. ' +
      'Interactive setup wizard that: 1) Creates sf360-playwright/ folder structure, ' +
      '2) Asks for SF360 credentials, 3) Creates .env file, 4) Installs dependencies (@playwright/test, otplib), ' +
      '5) Installs Playwright browsers, 6) Adds official Playwright MCP for browser automation, ' +
      '7) Verifies setup. Run this FIRST when setting up a new project.',
    inputSchema: {
      type: 'object',
      properties: {},
      required: [],
    },
    promptFile: 'init-prompt.md',
    promptSource: 'project',
  },
  {
    name: 'discover-page',
    description:
      'Explore a SF360 page and document all testable elements. ' +
      'Creates element inventory with selectors and suggests test scenarios. ' +
      'Automatically logs in before discovery.',
    inputSchema: {
      type: 'object',
      properties: {
        pageKey: {
          type: 'string',
          description: 'Page key from menu-mapping.json (e.g., "settings.badges", "connect.superstream_dashboard")',
        },
        outputFile: {
          type: 'string',
          description: 'Optional: Filename to save element inventory (defaults to [page-name].json)',
        },
      },
      required: ['pageKey'],
    },
    promptFile: 'discover-page-prompt.md',
    promptSource: 'project',
    variableMapper: (args) => ({
      PAGE_KEY: String(args.pageKey || ''),
      OUTPUT_FILE: String(args.outputFile || 'auto-generated'),
    }),
  },
  {
    name: 'add-page-mapping',
    description:
      'Add a new SF360 page entry to menu-mapping.json. ' +
      'Use this when a new page needs to be tested but is not in the current mapping.',
    inputSchema: {
      type: 'object',
      properties: {
        pageName: {
          type: 'string',
          description: 'Human-readable name for the page (e.g., "Badge Settings")',
        },
        url: {
          type: 'string',
          description: 'Page URL path without domain and query params (e.g., "/s/badge-settings/")',
        },
        section: {
          type: 'string',
          description: 'Menu section: HOME, WORKFLOW, CONNECT, COMPLIANCE, REPORTS, SETTINGS, S.ADMIN, or SYSTEMDATA',
        },
        pageKey: {
          type: 'string',
          description: 'Optional: Custom key to use in mapping (auto-generated from pageName if not provided)',
        },
      },
      required: ['pageName', 'url', 'section'],
    },
    promptFile: 'add-page-mapping-prompt.md',
    promptSource: 'project',
    variableMapper: (args) => ({
      PAGE_NAME: String(args.pageName || ''),
      URL: String(args.url || ''),
      SECTION: String(args.section || ''),
      PAGE_KEY: String(args.pageKey || 'auto-generate'),
    }),
  },
  {
    name: 'verify-setup',
    description:
      'Verify SF360 test environment setup. ' +
      'Checks dependencies (@playwright/test, otplib), .env configuration, Playwright browsers, and project structure. ' +
      'Automatically installs missing dependencies if found. ' +
      'Use this to troubleshoot issues or verify an existing setup. For first-time setup, use the "init" tool instead.',
    inputSchema: {
      type: 'object',
      properties: {},
      required: [],
    },
    promptFile: 'verify-setup-prompt.md',
    promptSource: 'project',
  },
];

// Package tools (load from templates/prompts/)
const packageTools: ToolConfig[] = [
  {
    name: 'sf360-test-plan',
    description:
      'Create structured test plan from user description. ' +
      'Analyzes user spec, detects target page, checks requirements (fund/member), ' +
      'extracts selectors from page discovery, and generates detailed plan JSON. ' +
      'Plan includes test steps, data requirements, and expected outcomes.',
    inputSchema: {
      type: 'object',
      properties: {
        spec: {
          type: 'string',
          description: 'User test description (e.g., "Create a new member and verify it appears in the list")',
        },
        testName: {
          type: 'string',
          description: 'Optional test file name (auto-generated if not provided)',
        },
        pageName: {
          type: 'string',
          description: 'Optional page hint (e.g., "members", "dashboard")',
        },
      },
      required: ['spec'],
    },
    promptFile: 'test-plan-prompt.md',
    promptSource: 'package',
    variableMapper: (args) => ({
      SPEC: String(args.spec || ''),
      TEST_NAME: String(args.testName || 'auto-generated'),
      PAGE_NAME: String(args.pageName || 'not specified'),
    }),
  },
  {
    name: 'sf360-test-generate',
    description:
      'Generate executable Playwright test from plan JSON. ' +
      'Reads plan file, generates test structure with setupTest(), ' +
      'creates test data variables with timestamps, converts plan steps to Playwright code, ' +
      'and writes test file to tests/ directory.',
    inputSchema: {
      type: 'object',
      properties: {
        planFile: {
          type: 'string',
          description: 'Path to plan JSON file from sf360-test-plan (e.g., "tests/plans/member-create-plan.json")',
        },
      },
      required: ['planFile'],
    },
    promptFile: 'test-generate-prompt.md',
    promptSource: 'package',
    variableMapper: (args) => ({
      PLAN_FILE: String(args.planFile || ''),
    }),
  },
  {
    name: 'sf360-test-evaluate',
    description:
      'Execute test, debug failures, and apply automatic fixes. ' +
      'Runs test with Playwright, analyzes failures, uses MCP Playwright to inspect pages, ' +
      'fixes selectors and timing issues iteratively. Smart limits: max 20 attempts, ' +
      'max 5 per error type, mandatory check-in at 10 attempts.',
    inputSchema: {
      type: 'object',
      properties: {
        testFile: {
          type: 'string',
          description: 'Path to test file from sf360-test-generate (e.g., "tests/member-create.spec.js")',
        },
        maxRetries: {
          type: 'number',
          description: 'Maximum fix attempts (default: 3)',
        },
        debug: {
          type: 'boolean',
          description: 'Enable debug mode with screenshots (default: false)',
        },
      },
      required: ['testFile'],
    },
    promptFile: 'test-evaluate-prompt.md',
    promptSource: 'package',
    variableMapper: (args) => ({
      TEST_FILE: String(args.testFile || ''),
    }),
  },
  {
    name: 'sf360-test-report',
    description:
      'Generate comprehensive test execution report. ' +
      'Creates markdown report with test metadata, execution result (PASS/FAIL), ' +
      'fixes applied, evidence (screenshots/logs for failures), and actionable next steps. ' +
      'Reports saved to tests/reports/ directory.',
    inputSchema: {
      type: 'object',
      properties: {
        testFile: {
          type: 'string',
          description: 'Path to test file (e.g., "tests/member-create.spec.js")',
        },
        planFile: {
          type: 'string',
          description: 'Path to plan JSON file (e.g., "tests/plans/member-create-plan.json")',
        },
        evaluationResult: {
          type: 'object',
          description: 'Result object from sf360-test-evaluate',
        },
      },
      required: ['testFile', 'planFile', 'evaluationResult'],
    },
    promptFile: 'test-report-prompt.md',
    promptSource: 'package',
    variableMapper: (args) => ({
      TEST_FILE: String(args.testFile || ''),
      PLAN_FILE: String(args.planFile || ''),
      EVALUATION_RESULT: JSON.stringify(args.evaluationResult || {}, null, 2),
    }),
  },
];

// Initialize MCP server
const mcpServer = new McpServer(
  {
    name: 'sf360-playwright-mcp',
    version: '0.2.0',
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// Register tools function
function registerTools(tools: ToolConfig[]) {
  tools.forEach((tool) => {
    mcpServer.registerTool(
      tool.name,
      {
        description: tool.description,
        inputSchema: tool.inputSchema as any,
      },
      async (args: any) => {
        try {
          // Load prompt based on source
          let prompt =
            tool.promptSource === 'project'
              ? loadPrompt(tool.promptFile)
              : loadPackagePrompt(tool.promptFile.replace('.md', ''), {});

          // Inject variables if mapper provided
          if (tool.variableMapper) {
            const variables = tool.variableMapper(args);
            for (const [key, value] of Object.entries(variables)) {
              prompt = prompt.replace(new RegExp(`{{${key}}}`, 'g'), value);
            }
          }

          return {
            content: [
              {
                type: 'text' as const,
                text: prompt,
              },
            ],
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : String(error);
          return {
            content: [
              {
                type: 'text' as const,
                text: `Error: ${errorMessage}`,
              },
            ],
            isError: true,
          };
        }
      }
    );
  });
}

// Register all tools
registerTools(projectTools);
registerTools(packageTools);

// Start MCP server
async function main() {
  const transport = new StdioServerTransport();
  await mcpServer.connect(transport);

  // Log to stderr (stdout reserved for MCP protocol)
  console.error('SF360 Playwright MCP Server running on stdio');
  console.error('Ready to receive tool calls from Claude');
}

main().catch((error) => {
  console.error('Fatal error in MCP server:', error);
  process.exit(1);
});
